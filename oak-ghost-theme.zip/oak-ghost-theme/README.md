Oak is clean and minimal, multipurpose Ghost theme. 
Following the main Ghost philosophy, Oak is created with just one thing on mind,
simplicity.

This theme is for all of you who are here to share your thoughts, stories and 
ideas with all of us. Thank you for that.

Oak Ghost theme is licensed under the General Public
License (GPL). You will find a copy of the GPL in the same directory 
as this text file.

Developed in January 2015. by Stefan Djokic